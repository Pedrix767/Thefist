import { createFileRoute } from "@tanstack/react-router";

// Imagens oficiais de cartas reais (Pokémon TCG — Base Set 1), via PokéTCG API.
// São referências remotas (https) — nenhum arquivo de terceiros é copiado para o projeto.
const CARD_IMAGES = {
  charizard: "https://images.pokemontcg.io/base1/4_hires.png",
  blastoise: "https://images.pokemontcg.io/base1/2_hires.png",
  venusaur: "https://images.pokemontcg.io/base1/15_hires.png",
  pikachu: "https://images.pokemontcg.io/base1/58_hires.png",
} as const;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "AURUM Vault — O cofre das cartas TCG raras",
      },
      {
        name: "description",
        content:
          "Cartas de TCG autenticadas e avaliadas: Charizard, Blastoise, Venusaur e outros clássicos. Inspeção em duas etapas antes de chegar até você.",
      },
      { property: "og:title", content: "AURUM Vault — O cofre das cartas TCG raras" },
      {
        property: "og:description",
        content:
          "Cartas autenticadas, notas verificadas e envio segurado. Navegue pelo cofre e colecione com confiança.",
      },
      { property: "og:type", content: "website" },
      { property: "og:image", content: CARD_IMAGES.charizard },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: CARD_IMAGES.charizard },
    ],
  }),
  component: Index,
});

const filters = ["Todas as cartas", "Holo raras", "Avulsas", "Lacrados"] as const;

const featured = [
  {
    name: "Blastoise",
    price: "R$ 480",
    detail: "Base Set 1 · Holo rara · 2/102",
    image: CARD_IMAGES.blastoise,
    alt: "Carta Blastoise holo rara do Base Set de Pokémon TCG",
  },
  {
    name: "Venusaur",
    price: "R$ 450",
    detail: "Base Set 1 · Holo rara · 15/102",
    image: CARD_IMAGES.venusaur,
    alt: "Carta Venusaur holo rara do Base Set de Pokémon TCG",
  },
  {
    name: "Pikachu",
    price: "R$ 160",
    detail: "Base Set 1 · Comum · 58/102",
    image: CARD_IMAGES.pikachu,
    alt: "Carta Pikachu do Base Set de Pokémon TCG",
  },
];

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background font-body text-foreground">
      {/* Ambient blobs */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -left-40 size-[560px] rounded-full bg-cobalt/25 blur-3xl"
        style={{ animation: "drift 14s ease-in-out infinite" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute top-1/3 -right-40 size-[520px] rounded-full bg-volt/25 blur-3xl"
        style={{ animation: "drift 18s ease-in-out infinite reverse" }}
      />

      <header className="sticky top-0 z-30 border-b border-edge bg-frost backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <span className="font-display text-2xl tracking-wide">AURUM</span>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-volt">vault</span>
          </div>
          <nav className="hidden items-center gap-7 text-sm md:flex">
            <a href="#destaques" className="transition hover:text-volt">
              Holo raras
            </a>
            <a href="#destaques" className="transition hover:text-volt">
              Avulsas
            </a>
            <a href="#confianca" className="transition hover:text-volt">
              Lacrados
            </a>
            <a href="#confianca" className="transition hover:text-volt">
              Vault
            </a>
          </nav>
          <a
            href="#destaques"
            className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-ice transition hover:bg-volt hover:text-ink"
          >
            Entrar
          </a>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="mx-auto grid max-w-6xl items-center gap-8 px-6 pt-16 pb-12 md:grid-cols-12">
          <div className="md:col-span-7">
            <h1 className="animate-clip-in font-display text-6xl leading-[0.92] tracking-tight text-balance md:text-8xl">
              O cofre onde as cartas raras vivem
            </h1>
            <p className="mt-5 max-w-[46ch] text-pretty text-ink/60">
              Cartas autênticas verificadas, avaliadas e enviadas com seguro — do Charizard do
              Base Set aos clássicos que você procura desde criança.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a
                href="#destaques"
                className="rounded-full bg-ink px-6 py-3 text-sm font-medium text-ice transition hover:bg-volt hover:text-ink"
              >
                Explorar o cofre
              </a>
              <a
                href="#confianca"
                className="rounded-full bg-frost px-6 py-3 text-sm font-medium ring-1 ring-black/5 backdrop-blur-md transition hover:ring-volt/40"
              >
                Vender uma carta
              </a>
            </div>
          </div>
          <div className="relative md:col-span-5">
            <div className="w-full overflow-hidden rounded-2xl outline-1 -outline-offset-1 outline-black/5">
              <img
                src={CARD_IMAGES.charizard}
                alt="Carta Charizard holo rara do Base Set de Pokémon TCG"
                width={640}
                height={896}
                className="aspect-[5/7] w-full object-cover"
              />
            </div>
            <div className="animate-rise absolute -bottom-4 -left-4 rounded-2xl bg-frost px-4 py-3 ring-1 ring-black/5 backdrop-blur-xl">
              <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-volt">Avaliada</div>
              <div className="font-display text-3xl">PSA 10</div>
            </div>
          </div>
        </section>

        {/* Filter bar */}
        <section className="mx-auto max-w-6xl px-6">
          <div className="flex gap-1 rounded-3xl bg-frost p-2 text-sm ring-1 ring-black/5 backdrop-blur-xl">
            {filters.map((label, i) => (
              <button
                key={label}
                className={`flex-1 rounded-2xl py-2 transition ${
                  i === 0 ? "bg-ink text-ice" : "hover:bg-black/5"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        {/* Featured cards */}
        <section id="destaques" className="mx-auto max-w-6xl px-6 py-12">
          <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
            {featured.map((card, i) => (
              <article
                key={card.name}
                className="group overflow-hidden rounded-2xl bg-frost ring-1 ring-black/5 backdrop-blur-xl transition hover:ring-volt/40"
                style={{ animation: `rise 0.5s cubic-bezier(0.32,0.72,0,1) both ${i * 60}ms` }}
              >
                <div className="overflow-hidden bg-white/70 outline-1 -outline-offset-1 outline-black/5">
                  <img
                    src={card.image}
                    alt={card.alt}
                    width={512}
                    height={720}
                    loading="lazy"
                    className="aspect-[3/4] w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                  />
                </div>
                <div className="p-4">
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-display text-2xl tracking-wide">{card.name}</h3>
                    <span className="font-mono text-xs text-volt">{card.price}</span>
                  </div>
                  <p className="mt-1 text-sm text-ink/55">{card.detail}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Trust */}
        <section id="confianca" className="mx-auto max-w-6xl px-6 pb-14">
          <div className="grid gap-6 rounded-3xl bg-frost p-8 ring-1 ring-black/5 backdrop-blur-xl md:grid-cols-3 md:p-10">
            <div>
              <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-volt">
                01 · Autenticado
              </div>
              <p className="mt-2 text-sm text-pretty">
                Toda carta passa por uma inspeção em duas etapas antes de chegar ao seu carrinho.
              </p>
            </div>
            <div>
              <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-volt">
                02 · Segurado
              </div>
              <p className="mt-2 text-sm text-pretty">
                Estoque climate controlado e segurado de ponta a ponta, do cofre até a sua porta.
              </p>
            </div>
            <div>
              <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-volt">
                03 · Protegido
              </div>
              <p className="mt-2 text-sm text-pretty">
                Checkout criptografado, cookies restritos e proteção ao comprador em cada pedido.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-edge bg-frost backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-col justify-between gap-6 px-6 py-10 md:flex-row md:items-end">
          <div className="font-display text-4xl tracking-wide">AURUM</div>
          <div className="flex gap-6 text-sm text-ink/55">
            <a href="#" className="transition hover:text-volt">
              Suporte
            </a>
            <a href="#" className="transition hover:text-volt">
              Termos
            </a>
            <a href="#" className="transition hover:text-volt">
              Privacidade
            </a>
          </div>
          <div className="font-mono text-xs text-ink/40">
            © 2026 Aurum Vault · Colecione com responsabilidade
          </div>
        </div>
      </footer>
    </div>
  );
}
